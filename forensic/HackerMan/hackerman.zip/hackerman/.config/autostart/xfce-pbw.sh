#/bin/sh
sleep 5
xfsettingsd --replace &
sleep 15
xfsettingsd --replace &
sleep 25
xfsettingsd --replace &
