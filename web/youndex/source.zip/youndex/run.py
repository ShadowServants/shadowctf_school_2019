from app import app

app.run(port=50005)