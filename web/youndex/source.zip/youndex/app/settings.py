SECRET_KEY = 'asdkaskdk12k31k23'
REDIS_HOST = 'redis'
REDIS_PORT = '6379'
REDIS_DB = '0'
MONGODB_DB = 'youndex'
MONGODB_HOST = 'mongo'
MONGODB_PORT = 27017
FLAG = "WILL BE HERE"
CELERY_BROKER_URL = 'redis://{host}:{port}/1'.format(host=REDIS_HOST, port=REDIS_PORT)
